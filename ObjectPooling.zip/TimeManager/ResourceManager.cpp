#include "pch.h"
#include "ResourceManager.h"
#include "Texture.h"
#include "CircleDamageSkillData.h"
#include "CircleDamageZoneData.h"
#include "CircleBulletSkillData.h"

ResourceManager::ResourceManager()
{

}
ResourceManager::~ResourceManager()
{
	for (auto iter = m_MapTexture.begin(); iter != m_MapTexture.end(); iter++)
		delete iter->second;
	for (auto iter = m_MapData.begin(); iter != m_MapData.end(); iter++)
	{
		for (auto iter2 = iter->second.begin(); iter2 != iter->second.end(); iter2++)
		{
			delete *iter2;
		}
	}
}

std::string ResourceManager::GetTextureFileName(TEXTURE_TYPE _eTextureType,DIRECTION _eDirection)
{
	switch (_eTextureType)
	{
	case TEXTURE_TYPE::BACKGROUND:			return "background.bmp";

	case TEXTURE_TYPE::PLAYER_IDLE_1:			return std::format("character_idle_{}_00.bmp", GetDirectionString(_eDirection));
	case TEXTURE_TYPE::PLAYER_IDLE_2:			return std::format("character_idle_{}_01.bmp", GetDirectionString(_eDirection));
	case TEXTURE_TYPE::PLAYER_IDLE_3:			return std::format("character_idle_{}_02.bmp", GetDirectionString(_eDirection));
	case TEXTURE_TYPE::PLAYER_IDLE_4:			return std::format("character_idle_{}_03.bmp", GetDirectionString(_eDirection));
	case TEXTURE_TYPE::PLAYER_IDLE_5:			return std::format("character_idle_{}_04.bmp", GetDirectionString(_eDirection));
	case TEXTURE_TYPE::PLAYER_IDLE_6:			return std::format("character_idle_{}_05.bmp", GetDirectionString(_eDirection));

	case TEXTURE_TYPE::PLAYER_RUN_1:			return std::format("character_run_{}_00.bmp", GetDirectionString(_eDirection));
	case TEXTURE_TYPE::PLAYER_RUN_2:			return std::format("character_run_{}_01.bmp", GetDirectionString(_eDirection));
	case TEXTURE_TYPE::PLAYER_RUN_3:			return std::format("character_run_{}_02.bmp", GetDirectionString(_eDirection));
	case TEXTURE_TYPE::PLAYER_RUN_4:			return std::format("character_run_{}_03.bmp", GetDirectionString(_eDirection));
	case TEXTURE_TYPE::PLAYER_RUN_5:			return std::format("character_run_{}_04.bmp", GetDirectionString(_eDirection));
	case TEXTURE_TYPE::PLAYER_RUN_6:			return std::format("character_run_{}_05.bmp", GetDirectionString(_eDirection));

	case TEXTURE_TYPE::PLAYER_ATTACK_1:			return std::format("character_attack_{}_00.bmp", GetDirectionString(_eDirection));
	case TEXTURE_TYPE::PLAYER_ATTACK_2:			return std::format("character_attack_{}_01.bmp", GetDirectionString(_eDirection));
	case TEXTURE_TYPE::PLAYER_ATTACK_3:			return std::format("character_attack_{}_02.bmp", GetDirectionString(_eDirection));
	case TEXTURE_TYPE::PLAYER_ATTACK_4:			return std::format("character_attack_{}_03.bmp", GetDirectionString(_eDirection));

	case TEXTURE_TYPE::MONSTER_IDLE_1:			return std::format("monster2_{}_00.bmp", GetDirectionString(_eDirection));
	case TEXTURE_TYPE::MONSTER_IDLE_2:			return std::format("monster2_{}_01.bmp", GetDirectionString(_eDirection));
	case TEXTURE_TYPE::MONSTER_IDLE_3:			return std::format("monster2_{}_02.bmp", GetDirectionString(_eDirection));

	case TEXTURE_TYPE::EFFECT_01_01:				return "Effect00.bmp";
	case TEXTURE_TYPE::EFFECT_01_02:				return "Effect01.bmp";
	case TEXTURE_TYPE::EFFECT_01_03:				return "Effect02.bmp";
	case TEXTURE_TYPE::EFFECT_01_04:				return "Effect03.bmp";
	case TEXTURE_TYPE::EFFECT_01_05:				return "Effect04.bmp";
	case TEXTURE_TYPE::EFFECT_01_06:				return "Effect05.bmp";

	case TEXTURE_TYPE::BULLET_01_01:				return "Bullet00.bmp";
	case TEXTURE_TYPE::BULLET_01_02:				return "Bullet01.bmp";
	case TEXTURE_TYPE::BULLET_01_03:				return "Bullet02.bmp";
	case TEXTURE_TYPE::BULLET_01_04:				return "Bullet03.bmp";
	case TEXTURE_TYPE::BULLET_01_05:				return "Bullet04.bmp";
	case TEXTURE_TYPE::BULLET_01_06:				return "Bullet05.bmp";
	default: return "";
	}
}

std::string ResourceManager::GetDirectionString(DIRECTION _eDirection)
{
	switch (_eDirection)
	{
	case DIRECTION::LEFT:
		return "left";
	case DIRECTION::RIGHT:
		return "right";
	case DIRECTION::UP:
		return "up";
	case DIRECTION::DOWN:
		return "down";
	default:
		break;
	}
	return std::string();
}

void ResourceManager::Init()
{
	std::ifstream FileNameLoad;
	std::string FileName = PathManager::GetInstance()->GetContentpath() +ConstValue::strDataPath + ConstValue::strDataTableNamesFileName;
	FileNameLoad.open(FileName);
	if (FileNameLoad.is_open())
	{
		while (FileNameLoad.eof() == false)
		{
			std::string FileName;
			FileNameLoad >> FileName;
			if (FileName == "CircleDamageSkill.txt")
				LoadData<CircleDamageSkillData>(FileName);
			else if(FileName == "CircleDamageZone.txt")
				LoadData<CircleDamageZoneData>(FileName);
			else if(FileName == "CircleBulletSkill.txt")
				LoadData<CircleBulletSkillData>(FileName);
		}
		FileNameLoad.close();
	}
}

Texture* ResourceManager::LoadTexture(TEXTURE_TYPE _eTextureType,DIRECTION _eDirection)
{
	std::string strFileName = GetTextureFileName(_eTextureType, _eDirection);
	assert(strFileName.length() != 0);

	std::string strKey = strFileName.substr(0, strFileName.length() - 4);

	Texture* pTexture = FindTexture(strKey);
	if (pTexture == nullptr)
	{
		pTexture = new Texture;
		std::string strPath = PathManager::GetInstance()->GetContentpath();
		strPath += ConstValue::strTexturePath + strFileName;
		pTexture->Load(strPath);
		pTexture->SetKey(strKey);
		pTexture->SetRelativePath(strFileName);
		m_MapTexture.insert(std::make_pair(strKey, pTexture));
	}
	return pTexture;
}

Texture* ResourceManager::FindTexture(const std::string& _strKey)
{
	std::map<std::string, Texture*>::iterator iter = m_MapTexture.find(_strKey);
	if (iter == m_MapTexture.end())
		return nullptr;
	else
		return iter->second;
}

Data* ResourceManager::GetData(std::string _strkey, int _iIndex)
{
	if(_iIndex >= m_MapData[_strkey].size())
		return nullptr;
	return m_MapData[_strkey][_iIndex];
}
