#pragma once
#include "Data.h"
class CircleBulletSkillData : public Data
{
private:
	int m_iCircleDamageZoneIndex;
	int m_iBulletIndex;
public:
	// Data��(��) ���� ��ӵ�
	void Load(std::ifstream& _loadFile) override;
	int GetCircleDamageZoneIndex() { return m_iCircleDamageZoneIndex; }
	int GetBulletIndex() { return m_iBulletIndex; }
};

