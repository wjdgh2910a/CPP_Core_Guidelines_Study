#pragma once
#include"GameResource.h"
class Texture : public GameResource
{
private:
	HDC m_hDC;
	HBITMAP m_hBitMap;
	BITMAP m_BitMapInfomation;
public:
	void Load(std::string _strFilePath);
	inline HDC GetDC() { return m_hDC; }
	inline int GetWidth() { return m_BitMapInfomation.bmWidth; }
	inline int GetHeight() { return m_BitMapInfomation.bmHeight; }
	Texture();
	~Texture();
};

