#include "pch.h"
#include "GameScene.h"
#include "Texture.h"
#include "Player.h"
#include "Monster.h"
#include "InputManager.h"
#include "CollisionManager.h"
#include "Bullet.h"

GameScene::GameScene(std::string _strName) : Scene(_strName)
{
	m_pBackGround = nullptr;
}

GameScene::~GameScene()
{
}

void GameScene::Init()
{
	srand(time(NULL));
	InputManager::GetInstance()->RegistKey(VK_SPACE);

	m_pBackGround = ResourceManager::GetInstance()->LoadTexture(TEXTURE_TYPE::BACKGROUND);
	Scene::SetWindowSize(ConstValue::vec2GameSceneWindowSize.m_fx, ConstValue::vec2GameSceneWindowSize.m_fy);

	Player* pPlayer = new Player;
	Vector2 vec2WindowSize = Scene::GetWindowSize();
	pPlayer->Init(ConstValue::vec2PlayerStartPosition);
	Scene::AddObject(pPlayer, OBJECT_GROUP::PLAYABLE);

	for (int i = 0; i < 60; ++i)
	{
		Monster* monster = new Monster;
		monster->Init();
		monster->SetEnabled(false);
		m_ObjectPool[static_cast<int>(OBJECT_GROUP::MONSTER)].push(monster);
		Scene::AddObject(monster, OBJECT_GROUP::MONSTER);
	}

	for (int i = 0; i < 1;++i)
	{
		Bullet* bullet = new Bullet;
		bullet->Init();
		bullet->SetEnabled(false);
		m_ObjectPool[static_cast<int>(OBJECT_GROUP::BULLET)].push(bullet);
		Scene::AddObject(bullet, OBJECT_GROUP::BULLET);
	}

	for (int i = 0; i < 50; ++i)
	{
		Monster* monster = nullptr;
		if (GetObjectPool<Monster>(OBJECT_GROUP::MONSTER, monster))
			monster->Init();
		float x = rand() % static_cast<int>(vec2WindowSize.m_fx);
		float y = rand() % static_cast<int>(vec2WindowSize.m_fy);
		monster->Init(Vector2{ x,y });
	}

	//�浹����
	CollisionManager::GetInstance()->RegistCollisionGroup(OBJECT_GROUP::MONSTER, OBJECT_GROUP::PLAYABLE);
	CollisionManager::GetInstance()->RegistCollisionGroup(OBJECT_GROUP::MONSTER, OBJECT_GROUP::PLAYER_SKILL);
	CollisionManager::GetInstance()->RegistCollisionGroup(OBJECT_GROUP::MONSTER, OBJECT_GROUP::BULLET);
}

void GameScene::Update()
{
	Scene::Update();
	Vector2 vec2WindowSize = Scene::GetWindowSize();


	for (int i = 0; i < Monster::s_iDieCount; ++i)
	{
		Monster* monster = nullptr;
		if (GetObjectPool<Monster>(OBJECT_GROUP::MONSTER, monster))
			monster->Init();
		float x = rand() % static_cast<int>(vec2WindowSize.m_fx);
		float y = rand() % static_cast<int>(vec2WindowSize.m_fy);
		monster->Init(Vector2{ x,y });
	}
	Monster::s_iDieCount = 0;
}

void GameScene::Render(HDC _memDC)
{
	BitBlt(_memDC, 0, 0, m_pBackGround->GetWidth(), m_pBackGround->GetHeight(),
		m_pBackGround->GetDC(), 0, 0, SRCCOPY);
	Scene::Render(_memDC);
}
