#pragma once
#include "Data.h"
class CircleDamageSkillData : public Data
{
private:
	int m_iCircleDamageZoneIndex;
	bool m_bUseTarget;
public:
	// Data��(��) ���� ��ӵ�
	void Load(std::ifstream& _loadFile) override;
	int GetCircleDamageZoneIndex() { return m_iCircleDamageZoneIndex; }
	bool GetUseTarget() { return m_bUseTarget; }
};

