#include "pch.h"
#include "Actor.h"
#include "TimerManager.h"
#include "GDIManager.h"

Actor::Actor()
{
	m_bMovable = true;
	m_iCurAnimation = -1;
	m_eDirection = DIRECTION::DOWN;
	m_fMoveSpeed = 100.0f;
	//Test Code
	m_pTarget = nullptr;
	m_fWeight = 0.0f;
}

Actor::~Actor()
{
}

void Actor::Move(Vector2 _vec2Force)
{
	if (m_bMovable == false)
		return;
	if (_vec2Force.isValid() == false)
		return;
	_vec2Force.Normalize();
	_vec2Force *= (m_fMoveSpeed * TimerManager::GetInstance()->GetdDeltaTime());
	Object::AddPosition(_vec2Force);
	if (_vec2Force.m_fx < 0.0f)
		SetDirection(DIRECTION::LEFT);
	else if(_vec2Force.m_fx > 0.0f)
		SetDirection(DIRECTION::RIGHT);
	else if(_vec2Force.m_fy < 0.0f)
		SetDirection(DIRECTION::UP);
	else if(_vec2Force.m_fy > 0.0f)
		SetDirection(DIRECTION::DOWN);
}

void Actor::ResizeAnimation(int _iSize)
{
	for (int i = DIRECTION::START; i != DIRECTION::END; ++i)
		m_AnimationList[i].resize(_iSize);
}

void Actor::InitAnimation(int _iIndex, int _iStartTextureIndex, int _iEndTextureIndex,
	float _fPlaySpeed, ANIMATION_TYPE _eAnimationType, ANCHOR _eAnchor)
{
	std::vector<AnimNode> vecAnimationList;
	for (int i = DIRECTION::START; i != DIRECTION::END; ++i)
	{
		assert(_iIndex < m_AnimationList[i].size());
		m_AnimationList[i][_iIndex].Init(static_cast<DIRECTION>(i),_iStartTextureIndex, _iEndTextureIndex, _eAnimationType, _fPlaySpeed, _eAnchor);
	}
}

void Actor::SetAnimationEvent(int _iIndex, int _iTextureIndex, std::function<void()> _pCallBack)
{
	for (int i = DIRECTION::START; i != DIRECTION::END; ++i)
	{
		assert(_iIndex < m_AnimationList[i].size());
		m_AnimationList[i][_iIndex].SetEvent(_iTextureIndex, _pCallBack);
	}
}

void Actor::Update()
{
	assert(m_iCurAnimation != -1);
	m_AnimationList[m_eDirection][m_iCurAnimation].Update();

	if (m_vec2Force.isValid())
	{
		Vector2 vec2Friction = (m_vec2Force * ConstValue::fFrictionCoefficient) * TimerManager::GetInstance()->GetfDeltaTime();
		m_vec2Force -= vec2Friction;
		m_vec2Force.ZeroSet();
		AddPosition(m_vec2Force * TimerManager::GetInstance()->GetfDeltaTime());
	}

	//Test Code
	//if (GetTarget() != nullptr)
	//{
	//	m_fWeight += TimerManager::GetInstance()->GetfDeltaTime() * 1.0f;
	//	m_fWeight = m_fWeight < 1.0f ? m_fWeight : 1.0f;
	//}
}

void Actor::Render(HDC _memDC)
{
	Object::Render(_memDC);
	m_AnimationList[m_eDirection][m_iCurAnimation].Render(_memDC, Object::GetPosition());

	//Test Code
	//if (GetTarget() != nullptr)
	//{
	//	GDIManager::GetInstance()->SetBrush(_memDC, BRUSH_TYPE::HOLLOW);
	//	GDIManager::GetInstance()->SetPen(_memDC, PEN_TYPE::RED);
	//	const Vector2 Position = GetPosition();
	//	const Vector2 Scale = GetScale();
	//	Rectangle(_memDC,
	//		Position.m_fx - Scale.m_fx / 2.0f - 30,
	//		Position.m_fy - Scale.m_fy / 2.0f - 30 + 30,
	//		Position.m_fx + Scale.m_fx / 2.0f + 30,
	//		Position.m_fy + Scale.m_fy / 2.0f + 30 + 30
	//	);

		//////////////////////////////////////////////////////////////////////////////
		//Bezier Curve 1D
		//////////////////////////////////////////////////////////////////////////////
		//MoveToEx(_memDC, GetPosition().m_fx, GetPosition().m_fy,nullptr);
		//LineTo(_memDC, TargetPoint.m_fx, TargetPoint.m_fy);
	
		//Vector2 Direction = GetPosition() - TargetPoint;
		//float Distance = Direction.Length();
		//Direction.Normalize();
		//Direction *= Distance * m_fWeight;
		//Vector2 Pos = TargetPoint + Direction;
		//Rectangle(_memDC, Pos.m_fx-5, Pos.m_fy-5,Pos.m_fx + 5,Pos.m_fy + 5);
		//std::string Message = std::format("x : {}, y : {}", Pos.m_fx,Pos.m_fy);
		//TextOut(_memDC, 0, 30, Message.c_str(), Message.length());
		//Message = std::format("Weight : {}", m_fWeight);
		//TextOut(_memDC, 0, 60, Message.c_str(), Message.length());
		//////////////////////////////////////////////////////////////////////////////
		// Bezier Curve 2D
		//////////////////////////////////////////////////////////////////////////////
		//Vector2 Direction = GetPosition() - TargetPoint;
		//float HalfDistance = Direction.Length() / 2.0f;
		//Direction.Normalize();
		//Vector2 HalfPosition = TargetPoint + Direction * HalfDistance;
		//Direction.RotationTheta(M_PI_2);
		//Vector2 P3 = HalfPosition + Direction * 100;
		//Rectangle(_memDC, P3.m_fx-5, P3.m_fy-5, P3.m_fx + 5, P3.m_fy + 5);

		//MoveToEx(_memDC, TargetPoint.m_fx, TargetPoint.m_fy, nullptr);
		//LineTo(_memDC, P3.m_fx, P3.m_fy);
		//MoveToEx(_memDC, P3.m_fx, P3.m_fy, nullptr);
		//LineTo(_memDC, GetPosition().m_fx, GetPosition().m_fy);

		//Vector2 TargetToDirection = P3 - TargetPoint;
		//float Distance = TargetToDirection.Length();
		//TargetToDirection.Normalize();
		//TargetToDirection *= Distance * m_fWeight;
		//Vector2 P4 = TargetPoint + TargetToDirection;

		//Rectangle(_memDC, P4.m_fx-5, P4.m_fy-5, P4.m_fx + 5, P4.m_fy + 5);
		//std::string Message = std::format("x : {}, y : {}", P4.m_fx, P4.m_fy);
		//TextOut(_memDC, 0, 30, Message.c_str(), Message.length());

		//Vector2 P3FromDirection = GetPosition() - P3;
		//Distance = P3FromDirection.Length();
		//P3FromDirection.Normalize();
		//P3FromDirection *= Distance * m_fWeight;
		//Vector2 P5 = P3 + P3FromDirection;

		//Rectangle(_memDC, P5.m_fx-5, P5.m_fy-5, P5.m_fx + 5, P5.m_fy + 5);
		//Message = std::format("x : {}, y : {}", P5.m_fx, P5.m_fy);
		//TextOut(_memDC, 0, 60, Message.c_str(), Message.length());

		//MoveToEx(_memDC, P4.m_fx, P4.m_fy, nullptr);
		//LineTo(_memDC, P5.m_fx, P5.m_fy);


		//Vector2 P4ToP5Direction = P5 - P4;
		//Distance = P4ToP5Direction.Length();
		//P4ToP5Direction.Normalize();
		//P4ToP5Direction *= Distance * m_fWeight;
		//Vector2 P6 = P4 + P4ToP5Direction;

		//Rectangle(_memDC, P6.m_fx - 5, P6.m_fy - 5, P6.m_fx + 5, P6.m_fy + 5);
		//Message = std::format("x : {}, y : {}", P6.m_fx, P6.m_fy);
		//TextOut(_memDC, 0, 90, Message.c_str(), Message.length());

		//Message = std::format("Weight : {}", m_fWeight);
		//TextOut(_memDC, 0, 120, Message.c_str(), Message.length());
	//}
}

void Actor::Init(Vector2 _vec2Position)
{
	Object::Init(_vec2Position);
}

void Actor::SetTarget(Actor* _pTarget)
{
	if (m_pTarget == nullptr && _pTarget != nullptr)
	{
		TargetPoint = _pTarget->GetPosition();
		m_fWeight = 0.0f;
	}
	m_pTarget = _pTarget;
}

void Actor::SetAnimation(int _iIndex)
{
	if (m_iCurAnimation == _iIndex)
		return;
	m_iCurAnimation = _iIndex;
	m_AnimationList[m_eDirection][m_iCurAnimation].Reset();
}
