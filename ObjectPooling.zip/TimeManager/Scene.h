#pragma once
#include"Object.h"
#include"Bullet.h"

struct GarbageObject
{
	Object* m_pObject;
	OBJECT_GROUP m_eGroup;
};

class Scene
{
protected:
	Vector2					m_vec2WindowStartPosition;
	Vector2					m_vec2WindowCenterPosition;
	Vector2					m_vec2WindowSize;
	std::vector<Object*>	m_arrObjects[static_cast<int>(OBJECT_GROUP::END)];
	std::string				m_strName;
	std::vector<GarbageObject>	m_arrGarbageObjects;
	std::queue<Object*>		m_ObjectPool[static_cast<int>(OBJECT_GROUP::END)];
public:
	Scene(std::string _strName);
	virtual ~Scene();
	virtual void Update();
	void LateUpdate();
	virtual void Render(HDC _memDC);
	virtual void Init() = 0;
	virtual void Release();
	inline const std::vector<Object*>& GetObjectGroup(OBJECT_GROUP _eObjectGrup) { return m_arrObjects[static_cast<int>(_eObjectGrup)]; }
	void SetWindowSize(int _iWidth, int _iHeight);
	void AddObject(Object* _object, OBJECT_GROUP _eGroup);
	inline Vector2 GetWindowSize() { return m_vec2WindowSize; }
	inline void SetName(const std::string _strName) { m_strName = _strName; }
	void AddGarbageObject(GarbageObject _object);
	void ClearGarbageObject();
	void DeleteObject(GarbageObject _object);
	
	inline void AddObjectPool(Object* object, OBJECT_GROUP _eGroup) 
	{
		object->SetEnabled(false); 
		m_ObjectPool[static_cast<int>(_eGroup)].push(object);
	}

	template <typename type>
	bool GetObjectPool(OBJECT_GROUP _eGroup,type*& _type)
	{
		if (m_ObjectPool[static_cast<int>(_eGroup)].empty() == true)
		{
			_type = new type;
			AddObject(_type, _eGroup);
			_type->SetEnabled(true);
			return true;
		}
		else
		{
			_type = static_cast<type*>(m_ObjectPool[static_cast<int>(_eGroup)].front());
			m_ObjectPool[static_cast<int>(_eGroup)].pop();
			_type->SetEnabled(true);
			return false;
		}
	}
};

