#include "pch.h"
#include "Monster.h"
#include "Collider.h"
#include "SceneManager.h"

int Monster::s_iDieCount = 0;

Monster::Monster()
{
}

Monster::~Monster()
{
}

void Monster::Init()
{
	SetActorType(ACTOR_TYPE::MONSTER);

	Actor::ResizeAnimation(ANIMATION::END);
	Actor::InitAnimation(ANIMATION::IDLE, TEXTURE_TYPE::MONSTER_IDLE_START, TEXTURE_TYPE::MONSTER_IDLE_END,0.5f);
	Actor::SetAnimation(ANIMATION::IDLE);

	Actor::SetMoveSpeed(200.0f);
	Collider* collider = CreateRectCollider(false, Vector2{ 40.0f, 40.0f }, Vector2{ 0.0f,30.0f });
	//Test Code
	collider->SetEndCollisionCallBack([&](Collider* _pOther) {
			SetTarget(nullptr);
		}
	);
}

void Monster::Init(Vector2 _vec2Position)
{
	Actor::SetPosition(_vec2Position);
	Actor::ResetForce();
}

void Monster::Update()
{
	Actor::Update();
	Vector2 Position = Object::GetPosition();
	if (Position.m_fx < 0 || Position.m_fx >= ConstValue::vec2GameSceneWindowSize.m_fx ||
		Position.m_fy < 0 || Position.m_fy >= ConstValue::vec2GameSceneWindowSize.m_fy)
	{
		s_iDieCount++;
		SceneManager::GetInstance()->GetCurScene()->AddObjectPool(this, OBJECT_GROUP::MONSTER);
	}
}

void Monster::Render(HDC _memDC)
{
	Actor::Render(_memDC);
}

void Monster::Attack(Collider* _pOther)
{
}
