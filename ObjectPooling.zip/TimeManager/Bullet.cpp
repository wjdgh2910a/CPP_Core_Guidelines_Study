#include "pch.h"
#include "Bullet.h"
#include "Actor.h"
#include "TimerManager.h"
#include "Collider.h"
#include "SceneManager.h"
#include "Monster.h"

Bullet::Bullet()
{
	m_pTarget = nullptr;
	m_fWeight = 0.0f;
	m_iHitCount = 0;
}

Bullet::~Bullet()
{
}

void Bullet::Init()
{
	m_Animation.Init(TEXTURE_TYPE::BULLET_01_START, TEXTURE_TYPE::BULLET_01_END, ANIMATION_TYPE::LOOP, 0.5f, ANCHOR::CENTER);
	m_pCollider = Object::CreateCircleCollider(true, 15.0f);
	m_pCollider->SetBeginCollisionCallBack([this](Collider* _pOther)
		{
			Actor* Target = dynamic_cast<Actor*>(_pOther->GetTarget());
			if (Target != nullptr)
			{
				Vector2 Force = Target->GetPosition() - Object::GetPosition();
				Force.Normalize();
				Force *= 200.0f;
				Target->AddForce(Force);
				m_iHitCount--;
				if (Target == m_pTarget || m_iHitCount == 0)
				{
					SceneManager::GetInstance()->GetCurScene()->AddObjectPool(this,OBJECT_GROUP::BULLET);
				}
			}
			else
			{
				SceneManager::GetInstance()->GetCurScene()->AddObjectPool(this, OBJECT_GROUP::BULLET);
			}
		});
}

void Bullet::Init(Vector2 _vec2Position, Actor* _pTarget, int _iHitCount)
{
	Object::SetPosition(_vec2Position);
	m_vec2Start = _vec2Position;
	SetTarget(_pTarget);
	SetHitCount(_iHitCount);
	m_fWeight = 0.0f;
}

void Bullet::Update()
{
	if (m_Animation.GetLive() == true)
		m_Animation.Update();
	if (m_pTarget->isEnabled() == false)
	{
		SceneManager::GetInstance()->GetCurScene()->AddObjectPool(this, OBJECT_GROUP::BULLET);
		return;
	}
	m_fWeight += TimerManager::GetInstance()->GetfDeltaTime() * 1.0f;
	m_fWeight = m_fWeight < 1.0f ? m_fWeight : 1.0f;
	Object::SetPosition( Vector2::GetBezierCurve2D(
		m_vec2Start,
		m_pTarget->GetPosition(),
		M_PI_4 + M_PI_2,
		300.0f,
		m_fWeight
		));
}

void Bullet::Render(HDC _memDC)
{
	Object::Render(_memDC);
	if (m_Animation.GetLive() == true)
		m_Animation.Render(_memDC, GetPosition());
}
