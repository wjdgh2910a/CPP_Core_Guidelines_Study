#include "pch.h"
#include "Skill.h"
#include "ResourceManager.h"
#include "CircleDamageSkillData.h"
#include "CircleBulletSkillData.h"
#include "CircleDamageZone.h"
#include "Actor.h"
#include "SceneManager.h"
#include "InputManager.h"
#include "Core.h"
#include "Bullet.h"


Skill::Skill(int _iIndex, Actor* _pCaster,int _iKey)
{
	m_iKey = _iKey;
	InputManager::GetInstance()->RegistKey(m_iKey);
	m_iIndex = _iIndex;
	m_pCaster = _pCaster;
	if (m_pCaster->GetActorType() == ACTOR_TYPE::PLAYER)
		m_eSKillGroup = OBJECT_GROUP::PLAYER_SKILL;
	else if (m_pCaster->GetActorType() == ACTOR_TYPE::MONSTER)
		m_eSKillGroup = OBJECT_GROUP::MONSTER_SKILL;
	else
		m_eSKillGroup = OBJECT_GROUP::BULLET;
}

void Skill::Input()
{

	switch (InputManager::GetInstance()->GetKeyState(m_iKey))
	{
	case KEY_STATE::DOWN:
		Create();
		break;
	case KEY_STATE::PRESS:
		Cast();
		break;
	case KEY_STATE::UP:
		Fire();
		break;
	}
}

CircleDamageSkill::CircleDamageSkill(int _iIndex, Actor* _pCaster, int _iKey)
	: Skill(_iIndex,_pCaster, _iKey)
{
	m_pSkillObject = nullptr;
}

void CircleDamageSkill::Cast()
{
	const std::list<Actor*>& targetList = m_pSkillObject->GetTargetList();
	for (Actor* actor : targetList)
	{
		Vector2 ForceDirection = m_pSkillObject->GetPosition() - actor->GetPosition();
		if (ForceDirection.Length() >= 30.0f)
		{
			ForceDirection.Normalize();
			actor->SetVelocity(ForceDirection * 30.0f);
		}
		else
			actor->SetVelocity({ 0.0f,0.0f });
	}
}

void CircleDamageSkill::Create()
{
	CircleDamageSkillData* data = static_cast<CircleDamageSkillData*>(ResourceManager::GetInstance()->GetData("CircleDamageSkill.txt", Skill::GetIndex()));
	if (data != nullptr)
	{
		if (m_pSkillObject == nullptr)
		{
			m_pSkillObject = new CircleDamageZone;
			SceneManager::GetInstance()->GetCurScene()->AddObject(m_pSkillObject, Skill::GetObjectGroup());
		}

		if (data->GetUseTarget() == true)
			m_pSkillObject->Init(data->GetCircleDamageZoneIndex(), Skill::GetCaster());
		else
		{

			m_pSkillObject->Init(data->GetCircleDamageZoneIndex());
			m_pSkillObject->SetPosition(Skill::GetCaster()->GetPosition());
		}
	}
}

void CircleDamageSkill::Fire()
{
	const std::list<Actor*>& targetList = m_pSkillObject->GetTargetList();
	for (Actor* actor : targetList)
	{
		Vector2 ForceDirection = actor->GetPosition() - m_pSkillObject->GetPosition();
		ForceDirection.Normalize();
		actor->AddForce(ForceDirection * 500.0f);
	}
	m_pSkillObject->SetEnable(false);
}

CircleBulletSkill::CircleBulletSkill(int _iIndex, Actor* _pCaster, int _iKey)
	: Skill(_iIndex, _pCaster, _iKey)
{
	m_pSkillObject = nullptr;
}

void CircleBulletSkill::Create()
{
	CircleBulletSkillData* data = static_cast<CircleBulletSkillData*>(ResourceManager::GetInstance()->GetData("CircleBulletSkill.txt", Skill::GetIndex()));
	if (data != nullptr)
	{
		if (m_pSkillObject == nullptr)
		{
			m_pSkillObject = new CircleDamageZone;
			SceneManager::GetInstance()->GetCurScene()->AddObject(m_pSkillObject, Skill::GetObjectGroup());
		}

		m_pSkillObject->Init(data->GetCircleDamageZoneIndex(), Skill::GetCaster());
	}
}

void CircleBulletSkill::Cast()
{
	//Test Code
	//const std::list<Actor*>& targetList = m_pSkillObject->GetTargetList();
	//for (Actor* actor : targetList)
	//{
	//	actor->SetTarget(GetCaster());
	//}
}

void CircleBulletSkill::Fire()
{
	//Test Code
	const std::list<Actor*>& targetList = m_pSkillObject->GetTargetList();
	for (Actor* actor : targetList)
	{
		Bullet* bullet = nullptr;
		if (SceneManager::GetInstance()->GetCurScene()->GetObjectPool<Bullet>(OBJECT_GROUP::BULLET, bullet))
			bullet->Init();
		bullet->Init(GetCaster()->GetPosition(), actor,4);
	}

	m_pSkillObject->SetEnable(false);
}
