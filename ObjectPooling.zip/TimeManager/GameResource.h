#pragma once
class GameResource
{
private:
	std::string m_strKey;
	std::string m_strRelativePath;
public:
	inline void SetKey(std::string _strKey) { m_strKey = _strKey; }
	inline void SetRelativePath(std::string _strRelativePath) { m_strRelativePath = _strRelativePath; }

	inline const std::string& GetKey() { return m_strKey; }
	inline const std::string& GetRelativePath() { return m_strRelativePath; }
	GameResource();
	~GameResource();
};

