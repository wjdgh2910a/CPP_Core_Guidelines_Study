#pragma once
#include "GameResource.h"
class Data : public GameResource
{
public:
	virtual void Load(std::ifstream& _loadFile) = 0;
};

