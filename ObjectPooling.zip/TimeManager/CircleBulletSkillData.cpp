#include "pch.h"
#include "CircleBulletSkillData.h"

void CircleBulletSkillData::Load(std::ifstream& _loadFile)
{
	int temp;
	_loadFile >> temp;
	_loadFile >> m_iCircleDamageZoneIndex;
	_loadFile >> m_iBulletIndex;
}
