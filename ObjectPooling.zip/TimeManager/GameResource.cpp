#include "pch.h"
#include "GameResource.h"

GameResource::GameResource()
{
}

GameResource::~GameResource()
{
}
