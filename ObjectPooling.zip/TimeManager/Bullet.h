#pragma once
#include "Object.h"
#include "Animation.h"
class Actor;
class Bullet : public Object
{
private:
	Actor* m_pTarget;
	float m_fWeight;
	Animation m_Animation;
	Vector2 m_vec2Start;
	int m_iHitCount;
	Collider* m_pCollider;
public:
	Bullet();
	~Bullet();
	void Init();
	void Init(Vector2 _vec2Position,Actor* _pTarget,int _iHitCount);
	void Update() override;
	void Render(HDC _memDC) override;
	inline void SetTarget(Actor* _pActor) { m_pTarget = _pActor; }
	inline void SetHitCount(int _iHitCount) { m_iHitCount = _iHitCount; }
};

