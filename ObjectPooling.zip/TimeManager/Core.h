#pragma once
class Core
{
	SINGLETON(Core)
private:
	HWND m_hWnd;
	HDC m_hDC;

	HBITMAP m_hBackBitMap;
	HDC m_hBackDC;
	void Update();
	void Render();
public:
	void CreateBackDC();
	void Init(HWND _hWnd);
	void GameLoop();
	inline HWND GethWnd() { return m_hWnd; }
	inline HDC GetMainDC() { return m_hDC; }
	inline HDC GetBackDC() { return m_hBackDC; }
};

