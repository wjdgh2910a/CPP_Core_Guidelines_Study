#include "pch.h"
#include "Scene.h"
#include "Core.h"
#include "InputManager.h"
#include "CollisionManager.h"

Scene::Scene(std::string _strName)
{
	m_strName = _strName;
	m_arrGarbageObjects.reserve(100);
}

Scene::~Scene()
{
	Release();
}

void Scene::Release()
{
	InputManager::GetInstance()->Clear();
	for (int i = 0; i < static_cast<int>(OBJECT_GROUP::END); i++)
	{
		for (Object* object : m_arrObjects[i])
		{
			delete object;
		}
		m_arrObjects[i].clear();
	}
	CollisionManager::GetInstance()->ReleaseCollisionGroup();
}

void Scene::SetWindowSize(int _iWidth, int _iHeight)
{
	Vector2 vec2ScreenStartPosition = { GetSystemMetrics(SM_CXSCREEN) / 2.0f,GetSystemMetrics(SM_CYSCREEN) / 2.0f };
	m_vec2WindowCenterPosition = { _iWidth / 2.0f ,_iHeight / 2.0f };
	m_vec2WindowStartPosition = { vec2ScreenStartPosition.m_fx - (_iWidth / 2.0f),
											  vec2ScreenStartPosition.m_fy - (_iHeight / 2.0f) };
	m_vec2WindowSize = { static_cast<float>(_iWidth),static_cast<float>(_iHeight)};

	SetWindowPos(Core::GetInstance()->GethWnd(), nullptr, m_vec2WindowStartPosition.m_fx, m_vec2WindowStartPosition.m_fy,
		_iWidth + 16, _iHeight + 39, SWP_SHOWWINDOW);
}

void Scene::AddObject(Object* _object, OBJECT_GROUP _eGroup)
{
	m_arrObjects[static_cast<int>(_eGroup)].push_back(_object);
}

void Scene::AddGarbageObject(GarbageObject _object)
{
	_object.m_pObject->SetEnabled(false); 
	m_arrGarbageObjects.push_back(_object);
}

void Scene::ClearGarbageObject()
{
	if (m_arrGarbageObjects.size() >= m_arrGarbageObjects.capacity() * 0.8f)
	{
		for (GarbageObject& garbage : m_arrGarbageObjects)
		{
			DeleteObject(garbage);
		}
		m_arrGarbageObjects.clear();
	}
}

void Scene::DeleteObject(GarbageObject _object)
{
	for (auto iter = m_arrObjects[static_cast<int>(_object.m_eGroup)].begin(); iter != m_arrObjects[static_cast<int>(_object.m_eGroup)].end(); iter++)
	{
		if (*iter == _object.m_pObject)
		{
			Object* object = *iter;
			m_arrObjects[static_cast<int>(_object.m_eGroup)].erase(iter);
			delete object;
			return;
		}
	}
}

void Scene::Update()
{
	for (int i = 0; i < static_cast<int>(OBJECT_GROUP::END); i++)
	{
		for (int j = 0; j < m_arrObjects[i].size(); j++)
		{
			if(m_arrObjects[i][j]->isEnabled() == true)
				m_arrObjects[i][j]->Update();
		}
	}
}

void Scene::LateUpdate()
{
	for (int i = 0; i < static_cast<int>(OBJECT_GROUP::END); i++)
	{
		for (int j = 0; j < m_arrObjects[i].size(); j++)
		{
			if (m_arrObjects[i][j]->isEnabled() == true)
				m_arrObjects[i][j]->LateUpdate();
		}
	}
}

void Scene::Render(HDC _memDC)
{
	for (int i = 0; i < static_cast<int>(OBJECT_GROUP::END); i++)
	{
		std::string Message = std::format("ObjectPool[{}] Count : {}",i, m_ObjectPool[i].size());
		TextOut(_memDC, 0, 50 + i * 20, Message.c_str(), Message.length());
	}
	for (int i = 0; i < static_cast<int>(OBJECT_GROUP::END); i++)
	{
		for (Object* object : m_arrObjects[i])
		{
			if (object->isEnabled() == true)
				object->Render(_memDC);
		}
	}
}
